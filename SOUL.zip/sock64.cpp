#include "INCLUDE/struct.h"
#define PSILENT_ARCH_ARM_64 1
#include "INCLUDE/psilent.cpp"
#include <vector>
#include <map>
#include <thread>
#include "Offsets64.h"

using namespace Offsets64;

uintptr_t getMatrix(uintptr_t base);
char* getBone(uintptr_t pBase, struct D3DMatrix viewMatrix);
uintptr_t getEntityAddr(uintptr_t base);
char* getWeaponId(uintptr_t base);
char* getNameByte(uintptr_t address);
PlayerWeapon getPlayerWeapon(uintptr_t base);
PlayerBone getPlayerBone(uintptr_t pBase, struct D3DMatrix viewMatrix);
void p_write(uintptr_t address, void* buffer, int size) {
	
	

}



uintptr_t GNames = 0, ViewWorld = 0;

int main()
{
    SetValue sv{};
    char sText[400];
    if (!isBeta)
    {
        if (!Create())
        {
            perror("Creation Failed");
            return 0;
        }
        if (!Connect())
        {
            perror("Connection Failed");
            return 0;
        }
        int no;


        receive((void*)&sv);
        no = sv.mode;
        if (no == 1){
	    GNames = 0xA60F6B0;
        ViewWorld = 0xAA27FA0;
		strcpy(version, "com.tencent.ig");
		} else if (no == 2){
	    GNames = 0xA60F6B0;        
        ViewWorld = 0xAA27FA0;
		strcpy(version, "com.pubg.krmobile");
		} else if (no == 3){	
	    GNames = 0xA6117B0;        
        ViewWorld = 0xAA2A098;
		strcpy(version, "com.vng.pubgmobile");
		} else if (no == 4){
	    GNames = 0xA60F6B0;        
        ViewWorld = 0xAA27FA0;
		strcpy(version, "com.rekoo.pubgm");
		} else if (no == 5){
	    GNames = 0xbe31160;        
        ViewWorld = 0xc2b4eb0;
		strcpy(version, "com.pubg.imobile");
		}
		

		
	}
	pid = getPid(version);
	if (pid < 10)
	{
		printf("\nGame is not running");
		Close();
		return 0;
	}
	if (isBeta == 1)
		printf("\n Game Pid: %d", pid);

	isPremium = true;
	uintptr_t base = getBase();
	if (isBeta == 1)
		printf("\n Base: %lX\n", base);

	    uintptr_t vMatrix = getMatrix(base);
    if (!vMatrix)
    {
        if (isBeta == 1)
            puts("\nMatrix Not Found");
        return 0;
    }
    if (isBeta == 1)
		printf("\nvMatrix: %lX", vMatrix);
    

	// looooooooooooooop
	uintptr_t enAddrPntr;
	float xy0, xy1;
	struct Vec3 xyz;
	struct Vec3 screen;
	struct Vec3 exyz;
	int isBack = 0, type = 69;
	int changed = 1;
	int myteamID = 101;
	uintptr_t cLoc = vMatrix + 0x750;   
	uintptr_t fovPntr = vMatrix + 0x660;   
    vMatrix = vMatrix + 0x590;   
	char loaded[0x4000], loadedpn[20];
	char name[100];
	uintptr_t gname_buff[30];
	uintptr_t gname = getA(getA(base + GNames) + 0x110);
	pvm(gname, &gname_buff, sizeof(gname_buff));
	char cont[0x500];
	char boneData[1024];
	struct D3DMatrix vMat;
	char weaponData[100];		


	Request request{};
	Response response{};

  std::thread* psilent_thread = nullptr;

	while (isBeta || (receive((void*)&request) > 0)) {
		if (!isBeta) {
			height = request.ScreenHeight;
			width = request.ScreenWidth;
		}

    static std::thread psilent_thread_{ps_MainLoop, pid, base, static_cast<float>(width), static_cast<float>(height)};
    psilent_thread = &psilent_thread_;

    if (request.Mode == InitMode) {
      {
        ps::gEnable = request.op.openState == 0;
      }
      {
        float fov_value = static_cast<float>(request.op.aimingRange);
        ps_SetOption(ps_OptionT::kFOVValue, &fov_value);
      }
      {
        ps_TargetBoneT target_bone;
        switch (request.op.aimbotmode) {
        case 1: {
          target_bone = ps_TargetBoneT::kHead;
        }
        case 2: {
          target_bone = ps_TargetBoneT::kNeck;
        }
        case 3: {
          target_bone = ps_TargetBoneT::kChest;
        }
        }
        ps_SetOption(ps_OptionT::kTargetBone, &target_bone);
      }
      {
        ps_AIMModeT aim_mode = request.op.priority == 0 ? ps_AIMModeT::k3DDistance : ps_AIMModeT::kDistanceToCrosshair;
        ps_SetOption(ps_OptionT::kAIMMode, &aim_mode);
      }
	  
    }

		response.Success = false;			      
		response.PlayerCount = 0;
		response.VehicleCount = 0;
		response.ItemsCount = 0;
		response.GrenadeCount = 0;
	    pvm(cLoc, &xyz, sizeof(xyz));
        if ((xyz.Z == 88.441124f || xyz.X == 0 || xyz.Z == 5278.43f || xyz.Z == 88.440918f) && !isBeta)
        {
            changed = 1;
            send((void*)&response, sizeof(response));
            continue;
        }
        pvm(fovPntr, &response.fov, 4);


        pvm(vMatrix, &vMat, sizeof(vMat));
        if (isBeta)
            printf("\nvMatChk: %0.1f | FOV: %0.2f | XYZ: %f %f %f", vMat._43, response.fov, xyz.X, xyz.Y, xyz.Z);
        // end


        // enList
        if (changed == 1) {
            enAddrPntr = getEntityAddr(base);
            changed = 0;
        }
        Ulevel ulevel;
        pvm(enAddrPntr, &ulevel, sizeof(ulevel));
        if (ulevel.size < 1 || ulevel.size > 0x1000 || !isValid64(ulevel.addr)) {
            if (isBeta)
                puts("\nWrong Entity Address");
            changed = 1;
            if (!isBeta) {
                send((void*)&response, sizeof(response));
                continue;
            }
        }
            if (isBeta)
            printf("\nEntity Address: %lX | Size: %d", enAddrPntr, ulevel.size);

        memset(loaded, 0, 1000);
        for (int i = 0; i < ulevel.size; i++) {
            uintptr_t pBase = getA(ulevel.addr + i * SIZE);
            if (!isValid64(pBase))
                continue;
            if (getI(pBase + SIZE) != 8)
                continue;
            int ids = getI(pBase + 8 + 2 * SIZE);
            int page = ids / 0x4000;
            int index = ids % 0x4000;
            if (page < 1 || page>30)
                continue;
            if (gname_buff[page] == 0)
                gname_buff[page] = getA(gname + page * SIZE);
            strcpy(name, getText(getA(gname_buff[page] + index * SIZE)));
            if (strlen(name) < 5)
				continue;

		
		if (strstr(name, "BP_PlayerPawn")||strstr(name, "BP_PlayerCharacter")||strstr(name, "PlanET_FakePlayer")) {//Player
				sprintf(loadedpn, "%lx,", pBase);
				if (strstr(loaded, loadedpn))
					continue;
				strcat(loaded, loadedpn);

				int oType = getI(pBase + 0x88);
				
			
				if (getI(pBase + bDead))
					continue;
                    
				pvm(pBase + Health, healthbuff, sizeof(healthbuff));
				if (healthbuff[1] > 200.0f || healthbuff[1] < 50.0f || healthbuff[0]>healthbuff[1] || healthbuff[0] < 0.0f)
					continue;
                    
				PlayerData* data = &response.Players[response.PlayerCount];
                
				data->Health = healthbuff[0] / healthbuff[1] * 100;

				data->TeamID = getI(pBase + TeamID);

				//me
				uintptr_t me = getI(pBase + Role);
                if (me == 258) {
                    if (isBeta)
                    printf("\nMe(%d): %lX ", data->TeamID, pBase);
                    myteamID = data->TeamID;
                    continue;
                }
                else if (me != 257)
                    continue;


                if (data->TeamID == myteamID && myteamID <= 100)
                    continue;
                    

                    
                    
uintptr_t boneAddr = getA(pBase + Mesh);
				exyz = mat2Cord(getOMatrix(getA(boneAddr + MinLOD) + 6 * 48), getOMatrix(boneAddr + FixAttachInfoList));

				data->HeadLocation = World2Screen(vMat, exyz);

				data->Distance = getDistance(xyz, exyz);
				if (data->Distance > 600.0f)
					continue;
				pvm(pBase + bIsAI, &data->isBot, sizeof(data->isBot));

				strcpy(data->PlayerNameByte, "66:111:116:");
				if (data->HeadLocation.Z != 1.0f && data->HeadLocation.X < width + 100 && data->HeadLocation.X > -50) {
		data->Bone = getPlayerBone(pBase, vMat);
						if (isPremium)
						strcpy(data->PlayerNameByte, getNameByte(getA(pBase + PlayerName)));
						if (strlen(data->PlayerNameByte) < 4)
							continue;
					if (isPremium)
						data->Weapon = getPlayerWeapon(pBase);
				}


				if (response.PlayerCount >= maxplayerCount) {
					continue;
				}
				
				response.PlayerCount++;

				if (isBeta)
					printf("\nE | %lX > TI:%d | H:%0.1f | XY: %0.1f %0.1f | %d", pBase, data->TeamID, data->Health, data->HeadLocation.X, data->HeadLocation.Y, data->isBot);

			}
			else if (strstr(name, "VH") || (strstr(name, "PickUp_") && !strstr(name, "BP")) || strstr(name, "Rony") || strstr(name, "Mirado") || strstr(name, "LadaNiva") || strstr(name, "AquaRail")) {//Vehicle
				if (!isPremium)
					continue;
				VehicleData* data = &response.Vehicles[response.VehicleCount];
				pvm(getA(pBase + RootComponent) + ParachuteEquipItems, &exyz, sizeof(exyz));

				data->Location = World2Screen(vMat, exyz);
				if (data->Location.Z == 1.0f || data->Location.X > width + 200 || data->Location.X < -200)
					continue;
				data->Distance = getDistance(xyz, exyz);
				strcpy(data->VehicleName, name);
				if (response.VehicleCount >= maxvehicleCount) {
					continue;
				}
				response.VehicleCount++;

				if (isBeta)
					printf("\nV | %lX > XY: %0.1f %0.1f | N: %s", pBase, data->Location.X, data->Location.Y, name);
			}
			else if (strstr(name, "Pickup_C") || strstr(name, "PickUp") || strstr(name, "BP_Ammo") || strstr(name, "BP_QK") || strstr(name, "Wrapper")) {//Items
				if (!isPremium)
					continue;
				ItemData* data = &response.Items[response.ItemsCount];
				pvm(getA(pBase + RootComponent) + ParachuteEquipItems, &exyz, sizeof(exyz));
				data->Location = World2Screen(vMat, exyz);
				if (data->Location.Z == 1.0f || data->Location.X > width + 100 || data->Location.X < -50)
					continue;
				data->Distance = getDistance(xyz, exyz);
				if (data->Distance > 200.0f)
					continue;
				strcpy(data->ItemName, name);
				if (response.ItemsCount >= maxitemsCount) {
					continue;
				}
				response.ItemsCount++;

				if (isBeta)
					printf("\nI | %lX > XY: %0.1f %0.1f | D:%0.1fm %s", pBase, data->Location.X, data->Location.Y, data->Distance, name);
			}
			else if (strstr(name, "BP_AirDropPlane_C") || strstr(name, "PlayerDeadInventoryBox_C") || strstr(name, "BP_AirDropBox_C")) {//Items
				if (!isPremium)
					continue;

				ItemData* data = &response.Items[response.ItemsCount];
				pvm(getA(pBase + RootComponent) + ParachuteEquipItems, &exyz, sizeof(exyz));
				data->Location = World2Screen(vMat, exyz);
				if (data->Location.Z == 1.0f || data->Location.X > width + 100 || data->Location.X < -50)
					continue;
				data->Distance = getDistance(xyz, exyz);
				strcpy(data->ItemName, name);
				if (response.ItemsCount >= maxitemsCount) {
					continue;
				}
				response.ItemsCount++;

				if (isBeta)
					printf("\nSp | %lX > XY: %0.1f %0.1f | D:%0.1fm %s", pBase, data->Location.X, data->Location.Y, data->Distance, name);
			}
			else if (strstr(name, "BP_Grenade_Shoulei_C") || strstr(name, "BP_Grenade_Burn_C") || strstr(name, "BP_Grenade_Stun_C") || strstr(name, "BP_Grenade_Smoke_C")) {//Grenade Warning
				if (!isPremium)
					continue;
				GrenadeData* data = &response.Grenade[response.GrenadeCount];
				pvm(getA(pBase + RootComponent) + ParachuteEquipItems, &exyz, sizeof(exyz));
				data->Location = World2Screen(vMat, exyz);               
				data->Distance = getDistance(xyz, exyz);
				if (data->Distance > 150.0f)
					continue;
				if (strstr(name, "Shoulei"))
					data->type = 1;
				else
                if (strstr(name, "Burn"))     
					data->type = 2;									
			    else
		    	if (strstr(name, "Stun"))
		    	    data->type = 3;
		    	else
		        if (strstr(name, "Smoke"))
		    	    data->type = 4;
				if (response.GrenadeCount >= maxgrenadeCount) {
					continue;
				}
				response.GrenadeCount++;

				if (isBeta)
					printf("\nGW | %lX > XY: %0.1f %0.1f | D:%0.1fm %d", pBase, data->Location.X, data->Location.Y, data->Distance, name);
			}


		}

		if (response.PlayerCount + response.ItemsCount + response.VehicleCount + response.GrenadeCount + response.GrenadeCount > 0)
			response.Success = true;

		    if (isBeta) {
            printf("\nPlayers: %d | Vehicle: %d | Items: %d ", response.PlayerCount, response.VehicleCount, response.ItemsCount);
            break;
        }

        send((void*)&response, sizeof(response));
        
    }

  ps::gCompleted = true;
  psilent_thread->join();

    if (isBeta)
        puts("\n\nScript Completed ");
}

struct Actors {
    uint64_t Enc_1, Enc_2;
    uint64_t Enc_3, Enc_4;
};

struct Chunk {
    uint32_t val_1, val_2, val_3, val_4;
    uint32_t val_5, val_6, val_7, val_8;
};

uint64_t DecryptActorsArray(uint64_t uLevel, int Actors_Offset, int EncryptedActors_Offset) {
    if (uLevel < 0x10000000)
        return 0;
 
    if (Read<uint64_t>(uLevel + Actors_Offset) > 0)
		return uLevel + Actors_Offset;
 
    if (Read<uint64_t>(uLevel + EncryptedActors_Offset) > 0)
		return uLevel + EncryptedActors_Offset;
 
    auto AActors = Read<Actors>(uLevel + EncryptedActors_Offset + 0x10);
 
    if (AActors.Enc_1 > 0) {
        auto Enc = Read<Chunk>(AActors.Enc_1 + 0x80);
        return (((Read<uint8_t>(AActors.Enc_1 + Enc.val_1)
            | (Read<uint8_t>(AActors.Enc_1 + Enc.val_2) << 8))
            | (Read<uint8_t>(AActors.Enc_1 + Enc.val_3) << 0x10)) & 0xFFFFFF
            | ((uint64_t)Read<uint8_t>(AActors.Enc_1 + Enc.val_4) << 0x18)
            | ((uint64_t)Read<uint8_t>(AActors.Enc_1 + Enc.val_5) << 0x20)) & 0xFFFF00FFFFFFFFFF
            | ((uint64_t)Read<uint8_t>(AActors.Enc_1 + Enc.val_6) << 0x28)
            | ((uint64_t)Read<uint8_t>(AActors.Enc_1 + Enc.val_7) << 0x30)
            | ((uint64_t)Read<uint8_t>(AActors.Enc_1 + Enc.val_8) << 0x38);
    }
    else if (AActors.Enc_2 > 0) {
        auto Lost_Actors = Read<uint64_t>(AActors.Enc_2);
        if (Lost_Actors > 0) {
            return (uint16_t)(Lost_Actors - 0x400) & 0xFF00
                | (uint8_t)(Lost_Actors - 0x04)
                | (Lost_Actors + 0xFC0000) & 0xFF0000
                | (Lost_Actors - 0x4000000) & 0xFF000000
                | (Lost_Actors + 0xFC00000000) & 0xFF00000000
                | (Lost_Actors + 0xFC0000000000) & 0xFF0000000000
                | (Lost_Actors + 0xFC000000000000) & 0xFF000000000000
                | (Lost_Actors - 0x400000000000000) & 0xFF00000000000000;
        }
    }
    else if (AActors.Enc_3 > 0) {
        auto Lost_Actors = Read<uint64_t>(AActors.Enc_3);
        if (Lost_Actors > 0) {
            return (Lost_Actors >> 0x38) | (Lost_Actors << (64 - 0x38));
		}
    }
    else if (AActors.Enc_4 > 0) {
        auto Lost_Actors = Read<uint64_t>(AActors.Enc_4);
        if (Lost_Actors > 0) {
            return Lost_Actors ^ 0xCDCD00;
		}
    }
    return 0;
}
uintptr_t getMatrix(uintptr_t base) {
    return getA(getA(base + ViewWorld) + 0xc0);
}

uintptr_t getEntityAddr(uintptr_t base) {
	uintptr_t level = getA(getA(getA(getA(base + ViewWorld) + 0x58) + 0x78) + 0x30);
    return DecryptActorsArray(level, 0xA0, 0x448);
}

PlayerBone getPlayerBone(uintptr_t pBase, struct D3DMatrix viewMatrix) {
    PlayerBone b;
    b.isBone = true;
    struct D3DMatrix oMatrix;
    uintptr_t boneAddr = getA(pBase + Mesh);
    struct D3DMatrix baseMatrix = getOMatrix(boneAddr + FixAttachInfoList);
    boneAddr = getA(boneAddr + MinLOD) + 0x30;
    // neck 0
    oMatrix = getOMatrix(boneAddr + 4 * 48);
    b.neck = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // cheast 1
    oMatrix = getOMatrix(boneAddr + 4 * 48);
    b.cheast = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // pelvis 2
    oMatrix = getOMatrix(boneAddr + 1 * 48);
    b.pelvis = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lSh 3
    oMatrix = getOMatrix(boneAddr + 11 * 48);
    b.lSh = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rSh 4
    oMatrix = getOMatrix(boneAddr + 32 * 48);
    b.rSh = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lElb 5
    oMatrix = getOMatrix(boneAddr + 12 * 48);
    b.lElb = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rElb 6
    oMatrix = getOMatrix(boneAddr + 33 * 48);
    b.rElb = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lWr 7
    oMatrix = getOMatrix(boneAddr + 63 * 48);
    b.lWr = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rWr 8
    oMatrix = getOMatrix(boneAddr + 62 * 48);
    b.rWr = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lTh 9
    oMatrix = getOMatrix(boneAddr + 52 * 48);
    b.lTh = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rTh 10
    oMatrix = getOMatrix(boneAddr + 56 * 48);
    b.rTh = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lKn 11
    oMatrix = getOMatrix(boneAddr + 53 * 48);
    b.lKn = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rKn 12
    oMatrix = getOMatrix(boneAddr + 57 * 48);
    b.rKn = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // lAn 13 
    oMatrix = getOMatrix(boneAddr + 54 * 48);
    b.lAn = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    // rAn 14
    oMatrix = getOMatrix(boneAddr + 58 * 48);
    b.rAn = World2ScreenMain(viewMatrix, mat2Cord(oMatrix, baseMatrix));
    return b;
}

PlayerWeapon getPlayerWeapon(uintptr_t base) {
	PlayerWeapon p;
	uintptr_t addr[3];
	pvm(getA(base + Children), addr, sizeof(addr));

	if (isValid64(addr[0]) && getI(addr[0] + DrawShootLineTime) == 2) {
		p.isWeapon = true;
		p.id = getI(getA(addr[0] + ShootWeaponEntityComp) + UploadInterval);
		p.ammo = getI(addr[0] + CurBulletNumInClip);
        p.maxammoz = Read<int>(addr[0] + CurMaxBulletNumInOneClip);
	}
	else if (isValid64(addr[1]) && getI(addr[1] + 0x134) == 2) {
		p.isWeapon = true;
	    p.id = Read<int>(getA(addr[1] + ShootWeaponEntityComp) + UploadInterval);
        p.ammo = Read<int>(addr[1] + CurBulletNumInClip);
        p.maxammoz = Read<int>(addr[1] + CurMaxBulletNumInOneClip);
	}
	else if (isValid64(addr[2]) && getI(addr[2] + 0x134) == 2) {
		p.isWeapon = true;
		p.id = Read<int>(getA(addr[2] + ShootWeaponEntityComp) + UploadInterval);
        p.ammo = Read<int>(addr[2] + CurBulletNumInClip);
        p.maxammoz = Read<int>(addr[2] + CurMaxBulletNumInOneClip);
	}

	return p;
}
